create view application_detail_view as
select `a`.`id`               AS `id`,
       `a`.`application_no`   AS `application_no`,
       `a`.`user_id`          AS `user_id`,
       `u`.`real_name`        AS `user_name`,
       `u`.`department`       AS `user_department`,
       `a`.`material_id`      AS `material_id`,
       `m`.`name`             AS `material_name`,
       `m`.`code`             AS `material_code`,
       `m`.`unit`             AS `material_unit`,
       `a`.`quantity`         AS `quantity`,
       `a`.`purpose`          AS `purpose`,
       `a`.`status`           AS `status`,
       `a`.`apply_time`       AS `apply_time`,
       `a`.`approve_time`     AS `approve_time`,
       `a`.`approve_user_id`  AS `approve_user_id`,
       `au`.`real_name`       AS `approve_user_name`,
       `a`.`reject_reason`    AS `reject_reason`,
       `a`.`outbound_time`    AS `outbound_time`,
       `a`.`outbound_user_id` AS `outbound_user_id`,
       `ou`.`real_name`       AS `outbound_user_name`,
       `a`.`is_abnormal`      AS `is_abnormal`,
       `a`.`abnormal_reason`  AS `abnormal_reason`,
       `a`.`remark`           AS `remark`
from ((((`office_supply_ms`.`application` `a` left join `office_supply_ms`.`user` `u` on ((`a`.`user_id` = `u`.`id`))) left join `office_supply_ms`.`user` `au` on ((`a`.`approve_user_id` = `au`.`id`))) left join `office_supply_ms`.`user` `ou` on ((`a`.`outbound_user_id` = `ou`.`id`)))
       left join `office_supply_ms`.`material` `m` on ((`a`.`material_id` = `m`.`id`)));

