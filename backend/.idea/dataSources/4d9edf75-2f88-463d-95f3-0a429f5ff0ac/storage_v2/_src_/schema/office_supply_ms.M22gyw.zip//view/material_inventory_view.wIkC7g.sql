create view material_inventory_view as
select `m`.`id`                        AS `id`,
       `m`.`code`                      AS `code`,
       `m`.`name`                      AS `name`,
       `m`.`category`                  AS `category`,
       `m`.`specification`             AS `specification`,
       `m`.`unit`                      AS `unit`,
       `m`.`unit_price`                AS `unit_price`,
       `m`.`current_stock`             AS `current_stock`,
       `m`.`min_stock`                 AS `min_stock`,
       `m`.`max_stock`                 AS `max_stock`,
       `m`.`abc_class`                 AS `abc_class`,
       `m`.`annual_consumption`        AS `annual_consumption`,
       `m`.`annual_consumption_amount` AS `annual_consumption_amount`,
       (case
          when (`m`.`current_stock` <= `m`.`min_stock`) then 'LOW'
          when (`m`.`current_stock` >= `m`.`max_stock`) then 'HIGH'
          else 'NORMAL' end)           AS `stock_status`
from `office_supply_ms`.`material` `m`;

